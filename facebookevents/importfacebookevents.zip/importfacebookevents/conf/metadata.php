<?php

$meta['fb_application_id'] = array('string');
$meta['fb_application_secret'] = array('string');

$meta['dformat'] = array('string');
$meta['tformat'] = array('string');

$meta['default'] = array('');
$meta['table'] = array('');
$meta['short'] = array('');

$meta['wallposts_default'] = array('');
$meta['wallposts_alternate'] = array('');
