<?php

$meta['dformat'] = array('string');
$meta['tformat'] = array('string');

$meta['default'] = array('');
$meta['table'] = array('');
$meta['article'] = array('');

?>