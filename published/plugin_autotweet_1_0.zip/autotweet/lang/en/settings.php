<?php

$lang['consumer_key'] = 'Consumer Key';
$lang['consumer_secret'] = 'Consumer Secret';
$lang['access_token'] = 'Access Token';
$lang['access_token_secret'] = 'Access Token Secret';
$lang['message_template'] = 'Message Template';
$lang['date_format'] = 'Date Format';

?>