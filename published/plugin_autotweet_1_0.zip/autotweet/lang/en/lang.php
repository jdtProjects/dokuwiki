<?php

$lang['creat'] = 'Create';
$lang['edit'] = 'Edit';
$lang['minor_edit'] = 'Minor Edit';
$lang['delete'] = 'Delete';
$lang['revert'] = 'Revert';

?>