<?php

$meta['consumer_key'] = array('string');
$meta['consumer_secret'] = array('string');
$meta['access_token'] = array('string');
$meta['access_token_secret'] = array('string');
$meta['message_template'] = array('string');
$meta['date_format'] = array('string');

?>