<?php

$conf['consumer_key'] = '';
$conf['consumer_secret'] = '';
$conf['access_token'] = '';
$conf['access_token_secret'] = '';
$conf['message_template'] = '{type} {page} - {summary} {user}';
$conf['date_format'] = '%Y/%m/%d %H:%M';

?>