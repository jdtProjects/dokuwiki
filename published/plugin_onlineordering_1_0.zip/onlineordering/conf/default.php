<?php
/**
 * Options for the onlineticket plugin
 *
 * @author Jannes Drost-Tenfelde <info@drost-tenfelde.de>
 */


$conf['sender_name'] = 'Online Ordering Plugin';
$conf['sender_email'] = 'noreply@onlineorderingplugin.com';
$conf['email_cc'] = 'sales@onlineorderingplugin.com';
$conf['bank_account'] = '';
$conf['countries'] = 'The Netherlands,Germany,United Kingdom';
$conf['signature'] = 'Kind regards,<br />Online Ordering Plugin';