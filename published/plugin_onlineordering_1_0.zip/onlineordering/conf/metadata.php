<?php
/**
 * Options for the onlineticket plugin
 *
 * @author Jannes Drost-Tenfelde <info@drost-tenfelde.de>
 */

$meta['sender_name']  = array('string');
$meta['sender_email']  = array('email');
$meta['email_cc']  = array('email');
$meta['bank_account']  = array('');
$meta['countries']  = array('');
$meta['signature']  = array('');

?>