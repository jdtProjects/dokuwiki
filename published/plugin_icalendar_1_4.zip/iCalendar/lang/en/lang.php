<?php
/**
 * English language file for plugin iCalEvents
 */

// custom language strings for the plugin
$lang['when']        = 'When';
$lang['what']        = 'What';
$lang['description'] = 'Description';
$lang['where']       = 'Where';
