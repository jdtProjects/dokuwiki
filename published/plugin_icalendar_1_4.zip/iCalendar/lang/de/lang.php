<?php
/**
 * German language file for plugin iCalEvents
 */

// custom language strings for the plugin
$lang['when']        = 'Wann';
$lang['what']        = 'Was';
$lang['description'] = 'Beschreibung';
$lang['where']       = 'Wo';
