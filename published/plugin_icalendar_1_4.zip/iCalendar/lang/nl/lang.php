<?php
/**
 * Dutch language file for plugin iCalEvents
 */

// custom language strings for the plugin
$lang['when']        = 'Wanneer';
$lang['what']        = 'Wat';
$lang['description'] = 'Beschrijving';
$lang['where']       = 'Waar';
