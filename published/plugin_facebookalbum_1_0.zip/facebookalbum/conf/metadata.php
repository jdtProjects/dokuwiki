<?php

$meta['appid'] = array('string');
$meta['secret'] = array('string');
$meta['fanpageid'] = array('string');
$meta['ignore'] = array('string');
$meta['order'] = array('string');

$meta['album_template'] = array('');
$meta['picture_template'] = array('');