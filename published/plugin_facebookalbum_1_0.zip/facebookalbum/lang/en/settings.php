<?php

$lang['appid'] = 'App ID of the Facebook App.';
$lang['secret'] = 'Secret of the Facebook App.';
$lang['fanpageid'] = 'ID of the Facebook Fanpage.';
$lang['ignore'] = 'List of album names, seperated by |, which should be ignored by the plugin.';
$lang['order'] = 'Order for the albums. Valid values: DESC (default) or ASC.';

$lang['album_template'] = 'Template for displaying facebook photo albums. Note: This template uses the standard DokuWiki syntax.';
$lang['picture_template'] = 'Template for displaying facebook pictures. Note: This template uses the standard DokuWiki syntax.';