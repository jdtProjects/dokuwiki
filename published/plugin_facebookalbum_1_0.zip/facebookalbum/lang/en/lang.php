<?php

$lang['no_description'] = 'There is currently no detailed information available.';

$lang['error'] = 'Errors have occurred:';
$lang['error_appid_not_set'] = 'Parameter <span id="parameter">applid</span> was not set';
$lang['error_secret_not_set'] = 'Parameter <span id="parameter">secret</span> was not set';
$lang['error_fanpageid_not_set'] = 'Parameter <span id="parameter">fanpageid</span> was not set';

$lang['back_to_albums'] = 'Back to albums >';