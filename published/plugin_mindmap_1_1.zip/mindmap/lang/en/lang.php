<?php

$lang['gexf_mindmap'] = 'GEXF Mindmap';

?>