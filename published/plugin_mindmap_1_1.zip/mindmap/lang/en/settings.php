<?php

$lang['path'] = 'The path to your local graphviz dot binary (eg. <code>/usr/bin/dot</code>). Leave empty to use remote rendering at google.com.';
$lang['use_plugin_path'] = 'Set this if you wish to manually set the path of the plugin. This may be necessary if you use .htaccess nice urls to fix broken images/links.';
$lang['plugin_path'] = 'The path of the mindmap plugin (eg. <code>http://yourwiki/lib/plugins/mindmap/</code>). The path can also be relative to a page you are displaying (ehg.<code>lib/plugins/mindmap/</code>)';

?>
