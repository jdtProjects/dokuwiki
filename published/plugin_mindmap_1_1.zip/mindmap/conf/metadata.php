<?php

$meta['graphviz_path'] = array('string');
$meta['use_plugin_path'] = array('onoff');
$meta['plugin_path'] = array('string');

?>