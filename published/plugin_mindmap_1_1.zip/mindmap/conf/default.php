<?php

$conf['graphviz_path'] = '';
$conf['use_plugin_path'] = 0;
$conf['plugin_path'] = '';

?>
